# -*- coding: utf-8 -*-
"""State container for the supervised (one-company-at-a-time) workflow."""

from dataclasses import dataclass
from typing import Optional, Dict, Any
from generate_application_assets import ApplicationAssets


@dataclass
class ApplicationState:
    company_index: int
    company_row: dict

    # Filled after OpenAI generation
    assets: Optional[ApplicationAssets] = None

    # Approval + artifacts
    resume_approved: bool = False
    cover_letter_approved: bool = False
    email_approved: bool = False

    resume_pdf_path: Optional[str] = None
    cover_letter_pdf_path: Optional[str] = None

    # Duplicate handling
    duplicate_found: bool = False
    duplicate_record: Optional[Dict[str, Any]] = None

    # Status: PENDING / DUPLICATE / GENERATED / RESUME_DONE / COVER_DONE / EMAIL_DONE / ERROR
    status: str = "PENDING"
    error: Optional[str] = None
