# -*- coding: utf-8 -*-
"""
Created on Mon Dec 15 14:33:22 2025

@author: Victor HELIES
"""
from pathlib import Path
from typing import List, Iterable, Optional
import copy

from docx import Document
from docx.text.paragraph import Paragraph
from docx.table import _Cell, Table
from docx.shared import Pt
from docx.oxml.ns import qn

import win32com.client

from docx.shared import RGBColor

import time
import os


# ---------- Paths ----------
PH_BASE_DIR = Path(__file__).resolve().parent
PH_TEMPLATE_PATH = PH_BASE_DIR / "input_files" / "resume_template.docx"

# ---------- Placeholders (must match your DOCX template exactly) ----------
PH_TITLE = "{{title}}"
PH_PROFILE = "{{profile_description}}"
PH_SKILLS = "{{key_skills}}"

# ---------- Font settings ----------
FONT_NAME = "Source Han Sans JP Normal"   # use the exact name shown in Word
TITLE_SIZE = 20
BODY_SIZE = 11


def set_run_font_all_slots(run, font_name: str, size_pt: float, color=RGBColor(0, 0, 0) ) -> None:
    """Force Word to use the same font for ascii/hAnsi/eastAsia/cs slots."""
    run.font.name = font_name
    run.font.size = Pt(size_pt)
    run.font.color.rgb = color

    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.get_or_add_rFonts()
    rFonts.set(qn("w:ascii"), font_name)
    rFonts.set(qn("w:hAnsi"), font_name)
    rFonts.set(qn("w:eastAsia"), font_name)
    rFonts.set(qn("w:cs"), font_name)

def run_has_shape(run) -> bool:
    el = run._element
    return el.xpath(".//w:pict") or el.xpath(".//w:drawing")

def clear_text_only(paragraph):
    # Clear text from runs, but DO NOT touch runs that contain shapes
    for r in paragraph.runs:
        if not run_has_shape(r):
            r.text = ""


def iter_paragraphs(doc: Document) -> Iterable[Paragraph]:
    """Yield all paragraphs in the document, including those inside tables."""
    yield from doc.paragraphs
    for tbl in doc.tables:
        yield from iter_paragraphs_in_table(tbl)


def iter_paragraphs_in_table(table: Table) -> Iterable[Paragraph]:
    for row in table.rows:
        for cell in row.cells:
            yield from iter_paragraphs_in_cell(cell)


def iter_paragraphs_in_cell(cell: _Cell) -> Iterable[Paragraph]:
    yield from cell.paragraphs
    for tbl in cell.tables:
        yield from iter_paragraphs_in_table(tbl)


def find_paragraph_containing(doc: Document, token: str) -> Optional[Paragraph]:
    for p in iter_paragraphs(doc):
        if token in p.text:
            return p
    return None


def clear_paragraph(paragraph: Paragraph) -> None:
    for run in paragraph.runs:
        run.text = ""


def replace_token_with_text(paragraph: Paragraph, token: str, text: str, size_pt: float, color, font) -> None:
    """Replace a token in a paragraph with text and apply font/size reliably."""
    # Remove token from existing runs (handles split runs)
    for run in paragraph.runs:
        #if token in run.text:
        #    run.text = run.text.replace(token, "")
        if not run_has_shape(run) and token in run.text:
            run.text = run.text.replace(token, "")

    # Clear everything and write a clean single run (predictable formatting)
    clear_text_only(paragraph)
    r = paragraph.add_run(text)
    set_run_font_all_slots(r, font, size_pt, color)


def insert_bullets_at_token(doc: Document, token: str, items: List[str], size_pt: float) -> None:
    p = find_paragraph_containing(doc, token)
    if p is None:
        raise ValueError(f"Token not found: {token}")

    # Clear the token paragraph and reuse it as the first bullet
    clear_paragraph(p)

    if not items:
        return

    p.style = "List Bullet"
    r0 = p.add_run(items[0])
    set_run_font_all_slots(r0, FONT_NAME, size_pt)

    parent_elm = p._p.getparent()
    idx = parent_elm.index(p._p)

    # Insert remaining bullets after the first paragraph
    for i, item in enumerate(items[1:], start=1):
        new_p = copy.deepcopy(p._p)
        parent_elm.insert(idx + i, new_p)
        new_para = Paragraph(new_p, p._parent)

        clear_paragraph(new_para)
        new_para.style = "List Bullet"
        r = new_para.add_run(item)
        set_run_font_all_slots(r, FONT_NAME, size_pt)


def docx_to_pdf(docx_path: str, pdf_path: str) -> None:
    docx_path = str(Path(docx_path).resolve())
    pdf_path = str(Path(pdf_path).resolve())

    word = win32com.client.Dispatch("Word.Application")
    word.Visible = False
    try:
        doc = word.Documents.Open(docx_path)
        doc.SaveAs(pdf_path, FileFormat=17)  # 17 = wdFormatPDF
        doc.Close(False)
    finally:
        word.Quit()


def fill_resume_template(template_path: str, output_path: str, title: str, profile: str, key_skills: List[str]) -> None:
    doc = Document(str(template_path))

    # Replace title/profile
    for p in iter_paragraphs(doc):
        if PH_TITLE in p.text:
            replace_token_with_text(p, PH_TITLE, title, TITLE_SIZE, RGBColor(31, 73, 125), "Source Han Sans JP" )
        if PH_PROFILE in p.text:
            replace_token_with_text(p, PH_PROFILE, profile, BODY_SIZE, RGBColor(0, 0, 0), "Source Han Sans JP Normal")

    # Skills bullets
    insert_bullets_at_token(doc, PH_SKILLS, key_skills, BODY_SIZE)

    doc.save(output_path)

    pdf_path = str(Path(output_path).with_suffix(".pdf"))
    docx_to_pdf(output_path, pdf_path)
    
    # ---- SAFE DELETE DOCX ----
    time.sleep(0.3)  # give Word time to release the file

    if Path(pdf_path).exists():
        os.remove(output_path)

"""
if __name__ == "__main__":
    fill_resume_template(
        template_path=str(TEMPLATE_PATH),
        output_path="Resume - YourName - AcmeCorp.docx",
        title="Business Analyst – FinTech",
        profile="Data-driven analyst with 4+ years improving reporting, automation, and stakeholder decision-making.",
        key_skills=["SQL", "Power BI", "Process Automation", "Stakeholder Management"],
    )
"""