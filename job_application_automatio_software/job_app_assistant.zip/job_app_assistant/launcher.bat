@echo off
REM ================================
REM Job Application Assistant Launcher
REM ================================

REM Move to the folder where this .bat file is located
cd /d "%~dp0"

REM Activate the correct Python interpreter
REM (Update this path if your Python location changes)
"C:\Program Files\WPy64-31160\python-3.11.6.amd64\python.exe" ui_app.py

REM Keep the window open if an error occurs
if errorlevel 1 (
    echo.
    echo An error occurred while running the application.
    pause
)
