# -*- coding: utf-8 -*-
"""Small CSV-backed database to prevent double applications."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import csv
from typing import Optional, Dict, Any, Iterable


DEFAULT_HEADERS = [
    "applied_at",
    "company_name",
    "company_email",
    "company_url",
    "resume_pdf",
    "cover_letter_pdf",
    "mode",
    "status",
]


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class ApplicationsDB:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_file()

    def _ensure_file(self) -> None:
        if self.path.exists():
            return
        with self.path.open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=DEFAULT_HEADERS)
            w.writeheader()

    def _iter_rows(self) -> Iterable[Dict[str, str]]:
        if not self.path.exists():
            return []
        with self.path.open("r", newline="", encoding="utf-8") as f:
            r = csv.DictReader(f)
            for row in r:
                yield dict(row)

    def find_duplicate(self, *, company_email: str, company_name: str, company_url: str) -> Optional[Dict[str, Any]]:
        email = (company_email or "").strip().lower()
        name = (company_name or "").strip().lower()
        url = (company_url or "").strip().lower()

        for row in self._iter_rows():
            r_email = (row.get("company_email") or "").strip().lower()
            r_name = (row.get("company_name") or "").strip().lower()
            r_url = (row.get("company_url") or "").strip().lower()

            if email and r_email and email == r_email:
                return row
            if (not email or not r_email) and name and r_name and url and r_url and name == r_name and url == r_url:
                return row

        return None

    def append_application(
        self,
        *,
        company_name: str,
        company_email: str,
        company_url: str,
        resume_pdf: str,
        cover_letter_pdf: str,
        mode: str,
        status: str = "sent",
        applied_at: Optional[str] = None,
    ) -> None:
        row = {
            "applied_at": applied_at or utc_now_iso(),
            "company_name": company_name,
            "company_email": company_email,
            "company_url": company_url,
            "resume_pdf": resume_pdf,
            "cover_letter_pdf": cover_letter_pdf,
            "mode": mode,
            "status": status,
        }
        with self.path.open("a", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=DEFAULT_HEADERS)
            w.writerow(row)
