# -*- coding: utf-8 -*-
"""Cover letter template filler + DOCX -> PDF via Word COM (same approach as resume_editor)."""

from pathlib import Path
from typing import Iterable, List
import copy
import time
import os

from docx import Document
from docx.text.paragraph import Paragraph
from docx.table import _Cell, Table
from docx.shared import Pt, RGBColor
from docx.oxml.ns import qn

import win32com.client


# ---------- Placeholders (must match your cover_letter_template.docx exactly) ----------
PH_SALUTATION = "{{salutation}}"
PH_BODY = "{{cover_letter_body}}"


# ---------- Font settings ----------
FONT_NAME = "Source Han Sans JP Normal"
BODY_SIZE = 11


def set_run_font_all_slots(run, font_name: str, size_pt: float, color=RGBColor(0, 0, 0)) -> None:
    run.font.name = font_name
    run.font.size = Pt(size_pt)
    run.font.color.rgb = color

    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.get_or_add_rFonts()
    rFonts.set(qn("w:ascii"), font_name)
    rFonts.set(qn("w:hAnsi"), font_name)
    rFonts.set(qn("w:eastAsia"), font_name)
    rFonts.set(qn("w:cs"), font_name)


def iter_paragraphs(doc: Document) -> Iterable[Paragraph]:
    yield from doc.paragraphs
    for tbl in doc.tables:
        yield from iter_paragraphs_in_table(tbl)


def iter_paragraphs_in_table(table: Table) -> Iterable[Paragraph]:
    for row in table.rows:
        for cell in row.cells:
            yield from iter_paragraphs_in_cell(cell)


def iter_paragraphs_in_cell(cell: _Cell) -> Iterable[Paragraph]:
    yield from cell.paragraphs
    for tbl in cell.tables:
        yield from iter_paragraphs_in_table(tbl)


def clear_paragraph(paragraph: Paragraph) -> None:
    for run in paragraph.runs:
        run.text = ""


def replace_token_with_text(paragraph: Paragraph, token: str, text: str, size_pt: float) -> None:
    for run in paragraph.runs:
        if token and token in run.text:
            run.text = run.text.replace(token, "")
    clear_paragraph(paragraph)
    r = paragraph.add_run(text)
    set_run_font_all_slots(r, FONT_NAME, size_pt)


def docx_to_pdf(docx_path: str, pdf_path: str) -> None:
    docx_path = str(Path(docx_path).resolve())
    pdf_path = str(Path(pdf_path).resolve())

    word = win32com.client.Dispatch("Word.Application")
    word.Visible = False
    try:
        doc = word.Documents.Open(docx_path)
        doc.SaveAs(pdf_path, FileFormat=17)  # 17 = wdFormatPDF
        doc.Close(False)
    finally:
        word.Quit()


def fill_cover_letter_template(
    template_path: str,
    output_path: str,
    salutation: str,
    body: str,
) -> None:
    """Fill cover letter placeholders and produce a PDF next to output_path."""
    doc = Document(str(template_path))

    blocks: List[str] = [blk.strip() for blk in body.replace("\r\n", "\n").split("\n\n") if blk.strip()]

    for p in iter_paragraphs(doc):
        if PH_SALUTATION in p.text:
            replace_token_with_text(p, PH_SALUTATION, salutation, BODY_SIZE)

        if PH_BODY in p.text:
            replace_token_with_text(p, PH_BODY, blocks[0] if blocks else "", BODY_SIZE)

            parent_elm = p._p.getparent()
            idx = parent_elm.index(p._p)

            for i, blk in enumerate(blocks[1:], start=1):
                new_p = copy.deepcopy(p._p)
                parent_elm.insert(idx + i, new_p)
                new_para = Paragraph(new_p, p._parent)
                replace_token_with_text(new_para, "", blk, BODY_SIZE)

    doc.save(output_path)

    pdf_path = str(Path(output_path).with_suffix(".pdf"))
    docx_to_pdf(output_path, pdf_path)

    time.sleep(0.3)
    if Path(pdf_path).exists():
        os.remove(output_path)
