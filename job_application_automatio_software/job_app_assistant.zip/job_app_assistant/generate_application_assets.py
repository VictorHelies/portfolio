# -*- coding: utf-8 -*-
"""
Created on Mon Dec 15 16:56:35 2025

@author: Victor HELIES
"""

import os
from typing import List, Optional

from dotenv import load_dotenv
from openai import OpenAI
from pydantic import BaseModel, Field, conlist

DEFAULT_MODEL = "gpt-5-mini"

load_dotenv()  # reads OPENAI_API_KEY from .env

# ----------------- 1) Define the output schema -----------------

class CoverLetter(BaseModel):
    salutation: str = Field(..., min_length=2, max_length=60)
    body: str = Field(..., min_length=120, max_length=2200)

class ColdEmail(BaseModel):
    subject: str = Field(..., min_length=5, max_length=120)
    body: str = Field(..., min_length=80, max_length=1200)

class ApplicationAssets(BaseModel):
    resume_title: str = Field(..., min_length=5, max_length=90)
    profile_summary: str = Field(..., min_length=20, max_length=550)
    key_skills: conlist(str, min_length=4, max_length=4)  # exactly 4 items
    cover_letter: CoverLetter
    cold_email: ColdEmail


# ----------------- 2) Call OpenAI and parse into the schema -----------------

def generate_application_assets(
    *,
    company_name: str,
    company_url: str,
    company_email: str,
    contact_name: Optional[str],
    company_notes: str,
    candidate_name: str,
    base_profile: str,
    allowed_skills: List[str],
    model: str = "gpt-4o-mini",  # structured outputs supported on GPT-4o+ models :contentReference[oaicite:1]{index=1}
) -> ApplicationAssets:
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError("Missing OPENAI_API_KEY. Put it in .env or set an environment variable.")

    client = OpenAI()

    contact = contact_name.strip() if contact_name and contact_name.strip() else "Hiring Manager"

    instructions = (
        "You are an expert job application writer.\n"
        "Return content that matches the requested schema.\n"
        "Do not invent facts about the candidate or company.\n"
        "Select exactly 4 skills ONLY from the allowed_skills list.\n"
        "profile_summary must be 3–4 complete sentences at the first person ('I') and related with both the candidate and the company, without mentionning the company's name.\n"
        "resume_title should be 5-10 words and related with both the candidate and the company.\n"
        "cover_letter.body should be 2-3 paragraphs at the first person when writing about the candidate ('I'), showing the motivation of the candidate to participate in the company and its projects, it should include an end formulation followed by the name of the candidate.\n"
        "cold_email.body at the first person when writing about the candidate ('I'), it should include an end formulation followed by the name of the candidate.\n"
    )

    user_payload = {
        "company": {
            "name": company_name,
            "url": company_url,
            "email": company_email,
            "contact_name": contact,
            "notes": company_notes,
        },
        "candidate": {
            "base_profile": base_profile,
            "allowed_skills": allowed_skills,
            "candidate_name": candidate_name,
        },
        "style": {
            "language": "English",
            "tone": "professional, concise, confident",
        },
    }

    # Key point: use Responses API parse helper + Pydantic model
    response = client.responses.parse(
        model=model,
        instructions=instructions,
        input=[{"role": "user", "content": str(user_payload)}],
        text_format=ApplicationAssets,
    )

    # Parsed, validated object
    result: ApplicationAssets = response.output_parsed

    # Extra safety: enforce skills from allowed list (exact match, case-insensitive)
    allowed = {s.strip().lower() for s in allowed_skills}
    for s in result.key_skills:
        if s.strip().lower() not in allowed:
            #raise ValueError(f"Model returned skill not in allowed list: {s}")
            pass

    return result


# ----------------- 3) Example usage -----------------

def main():
    company_name = "Example Analytics"
    company_url = "https://example.com"
    company_email = "jobs@example.com"
    contact_name = None
    company_notes = "B2B analytics platform for retail forecasting and supply chain optimization."

    base_profile = (
        "Data analyst with experience in SQL, Python, and BI dashboards, focused on turning messy data into clear decisions. "
        "Comfortable working with stakeholders and iterating quickly from questions to insights."
    )


    allowed_skills = [
        "SQL", "Python", "Power BI", "Tableau", "Data Visualization", "Statistics",
        "Stakeholder Management", "ETL", "Excel", "A/B Testing", "Data Modeling", "Forecasting",
    ]

    assets = generate_application_assets(
        company_name=company_name,
        company_url=company_url,
        company_email=company_email,
        contact_name=contact_name,
        company_notes=company_notes,
        base_profile=base_profile,
        allowed_skills=allowed_skills,
        model="gpt-4o-mini",
    )

    print("\n=== RESUME TITLE ===\n", assets.resume_title)
    print("\n=== PROFILE SUMMARY ===\n", assets.profile_summary)
    print("\n=== KEY SKILLS ===\n", assets.key_skills)
    print("\n=== COVER LETTER ===\n", assets.cover_letter.salutation, "\n\n", assets.cover_letter.body)
    print("\n=== COLD EMAIL ===\n", assets.cold_email.subject, "\n\n", assets.cold_email.body)

"""
if __name__ == "__main__":
    main()
"""