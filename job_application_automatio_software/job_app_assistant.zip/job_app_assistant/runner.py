# -*- coding: utf-8 -*-
"""Supervised runner with duplicate prevention + resume + cover letter + email."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import generate_application_assets as gaa
import resume_editor as re
import cover_letter_editor as cle
import mail_sender as ms

from application_state import ApplicationState
from application_db import ApplicationsDB


def sanitize_filename(name: str) -> str:
    bad = '<>:"/\\|?*'
    out = "".join("_" if c in bad else c for c in (name or "").strip())
    out = " ".join(out.split())
    return out[:120] if out else "Company"


class ApplicationRunner:
    def __init__(
        self,
        companies_df,
        resume_template_path: str,
        cover_template_path: str,
        output_dir: str,
        candidate_name: str,
        base_profile: str,
        allowed_skills,
        mail_mode: str = "draft",
        db_path: Optional[str] = None,
    ):
        self.df = companies_df.reset_index(drop=True)

        self.resume_template_path = resume_template_path
        self.cover_template_path = cover_template_path

        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        self.candidate_name = candidate_name
        self.base_profile = base_profile
        self.allowed_skills = allowed_skills
        self.mail_mode = mail_mode

        self.db = ApplicationsDB(Path(db_path) if db_path else (self.output_dir / "applications_log.csv"))

        self.index = 0
        self.current_state: Optional[ApplicationState] = None

    def generate_next(self, *, force: bool = False) -> ApplicationState:
        if self.index >= len(self.df):
            raise StopIteration("No more companies")

        row = self.df.iloc[self.index].to_dict()

        dup = self.db.find_duplicate(
            company_email=str(row.get("email", "")),
            company_name=str(row.get("name", "")),
            company_url=str(row.get("url", "")),
        )

        if dup and not force:
            self.current_state = ApplicationState(
                company_index=self.index,
                company_row=row,
                assets=None,
                duplicate_found=True,
                duplicate_record=dup,
                status="DUPLICATE",
            )
            return self.current_state

        assets = gaa.generate_application_assets(
            company_name=row["name"],
            company_url=row.get("url", ""),
            company_email=row["email"],
            contact_name=row.get("contact_name", ""),
            company_notes=row.get("notes", ""),
            candidate_name=self.candidate_name,
            base_profile=self.base_profile,
            allowed_skills=self.allowed_skills,
            model="gpt-4o-mini",
        )

        self.current_state = ApplicationState(
            company_index=self.index,
            company_row=row,
            assets=assets,
            status="GENERATED",
        )

        return self.current_state

    def approve_resume(self) -> str:
        state = self.current_state
        if not state or not state.assets:
            raise RuntimeError("Nothing to approve")

        row = state.company_row
        safe_name = sanitize_filename(str(row.get("name", "Company")))

        output_docx = self.output_dir / f"Engineering_intern_{safe_name}_{self.candidate_name}.docx"

        re.fill_resume_template(
            template_path=str(self.resume_template_path),
            output_path=str(output_docx),
            title=state.assets.resume_title,
            profile=state.assets.profile_summary,
            key_skills=list(state.assets.key_skills),
        )

        pdf_path = str(output_docx.with_suffix(".pdf"))
        state.resume_pdf_path = pdf_path
        state.resume_approved = True
        state.status = "RESUME_DONE"
        return pdf_path

    def approve_cover_letter(self) -> str:
        state = self.current_state
        if not state or not state.assets:
            raise RuntimeError("Nothing to approve")

        row = state.company_row
        safe_name = sanitize_filename(str(row.get("name", "Company")))

        output_docx = self.output_dir / f"CoverLetter_{safe_name}_{self.candidate_name}.docx"

        cle.fill_cover_letter_template(
            template_path=str(self.cover_template_path),
            output_path=str(output_docx),
            salutation=state.assets.cover_letter.salutation,
            body=state.assets.cover_letter.body,
        )

        pdf_path = str(output_docx.with_suffix(".pdf"))
        state.cover_letter_pdf_path = pdf_path
        state.cover_letter_approved = True
        state.status = "COVER_DONE"
        return pdf_path

    def approve_email(self) -> None:
        state = self.current_state
        if not state or not state.assets:
            raise RuntimeError("Generate assets first")
        if not state.resume_approved:
            raise RuntimeError("Resume not approved yet")
        if not state.cover_letter_approved:
            raise RuntimeError("Cover letter not approved yet")

        row = state.company_row
        email = state.assets.cold_email

        ms.send_email(
            adress=row["email"],
            subject=email.subject,
            body=email.body,
            attachments=[state.resume_pdf_path, state.cover_letter_pdf_path],
            mode=self.mail_mode,
        )

        self.db.append_application(
            company_name=str(row.get("name", "")),
            company_email=str(row.get("email", "")),
            company_url=str(row.get("url", "")),
            resume_pdf=str(state.resume_pdf_path or ""),
            cover_letter_pdf=str(state.cover_letter_pdf_path or ""),
            mode=str(self.mail_mode),
            status="sent" if self.mail_mode == "send" else "draft",
        )

        state.email_approved = True
        state.status = "EMAIL_DONE"
        self.index += 1
        self.current_state = None

    def skip_current(self) -> None:
        self.index += 1
        self.current_state = None
