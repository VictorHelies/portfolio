# -*- coding: utf-8 -*-
"""PySide6 GUI for supervised job application workflow."""

import sys
from pathlib import Path

import pandas as pd
from PySide6.QtCore import QObject, QThread, Signal, Slot, Qt
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget,
    QVBoxLayout, QHBoxLayout, QFormLayout,
    QPushButton, QLabel, QLineEdit, QTextEdit,
    QFileDialog, QMessageBox, QComboBox
)

from runner import ApplicationRunner


class GenerateWorker(QObject):
    finished = Signal(object)
    error = Signal(str)

    def __init__(self, runner: ApplicationRunner, force: bool = False):
        super().__init__()
        self.runner = runner
        self.force = force

    @Slot()
    def run(self):
        try:
            state = self.runner.generate_next(force=self.force)
            self.finished.emit(state)
        except Exception as e:
            self.error.emit(str(e))


class ResumeWorker(QObject):
    finished = Signal(str)
    error = Signal(str)

    def __init__(self, runner: ApplicationRunner):
        super().__init__()
        self.runner = runner

    @Slot()
    def run(self):
        try:
            pdf_path = self.runner.approve_resume()
            self.finished.emit(str(pdf_path))
        except Exception as e:
            self.error.emit(str(e))


class CoverWorker(QObject):
    finished = Signal(str)
    error = Signal(str)

    def __init__(self, runner: ApplicationRunner):
        super().__init__()
        self.runner = runner

    @Slot()
    def run(self):
        try:
            pdf_path = self.runner.approve_cover_letter()
            self.finished.emit(str(pdf_path))
        except Exception as e:
            self.error.emit(str(e))


class EmailWorker(QObject):
    finished = Signal()
    error = Signal(str)

    def __init__(self, runner: ApplicationRunner):
        super().__init__()
        self.runner = runner

    @Slot()
    def run(self):
        try:
            self.runner.approve_email()
            self.finished.emit()
        except Exception as e:
            self.error.emit(str(e))


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Job Application Assistant (Supervised)")
        self.resize(1150, 820)

        self.runner = None
        self.state = None

        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)

        cfg_row = QHBoxLayout()
        layout.addLayout(cfg_row)

        self.csv_label = QLabel("Companies CSV: (not loaded)")
        self.resume_tpl_label = QLabel("Resume template: (not loaded)")
        self.cover_tpl_label = QLabel("Cover template: (not loaded)")
        self.out_label = QLabel("Output folder: (not selected)")

        pick_csv_btn = QPushButton("Pick CSV")
        pick_resume_tpl_btn = QPushButton("Pick Resume Template")
        pick_cover_tpl_btn = QPushButton("Pick Cover Template")
        pick_out_btn = QPushButton("Pick Output Folder")

        pick_csv_btn.clicked.connect(self.pick_csv)
        pick_resume_tpl_btn.clicked.connect(self.pick_resume_template)
        pick_cover_tpl_btn.clicked.connect(self.pick_cover_template)
        pick_out_btn.clicked.connect(self.pick_output)

        cfg_left = QVBoxLayout()
        cfg_left.addWidget(self.csv_label)
        cfg_left.addWidget(self.resume_tpl_label)
        cfg_left.addWidget(self.cover_tpl_label)
        cfg_left.addWidget(self.out_label)

        cfg_right = QVBoxLayout()
        cfg_right.addWidget(pick_csv_btn)
        cfg_right.addWidget(pick_resume_tpl_btn)
        cfg_right.addWidget(pick_cover_tpl_btn)
        cfg_right.addWidget(pick_out_btn)

        cfg_row.addLayout(cfg_left, 3)
        cfg_row.addLayout(cfg_right, 1)

        mode_row = QHBoxLayout()
        layout.addLayout(mode_row)
        mode_row.addWidget(QLabel("Email mode:"))
        self.mode_combo = QComboBox()
        self.mode_combo.addItems(["draft", "send"])
        self.mode_combo.setCurrentText("draft")
        mode_row.addWidget(self.mode_combo)
        mode_row.addStretch(1)

        form = QFormLayout()
        layout.addLayout(form)

        self.company_info = QLabel("Company: —")
        self.company_info.setTextInteractionFlags(Qt.TextBrowserInteraction)
        self.company_info.setOpenExternalLinks(True)
        self.company_info.setWordWrap(True)
        form.addRow("Current company", self.company_info)

        self.title_edit = QLineEdit()
        form.addRow("Resume title", self.title_edit)

        self.profile_edit = QTextEdit()
        self.profile_edit.setFixedHeight(70)
        form.addRow("Profile summary", self.profile_edit)

        self.skills_edit = QTextEdit()
        self.skills_edit.setFixedHeight(70)
        self.skills_edit.setPlaceholderText("One skill per line (exactly 4)")
        form.addRow("Key skills", self.skills_edit)

        self.cover_salutation_edit = QLineEdit()
        form.addRow("Cover letter salutation", self.cover_salutation_edit)

        self.cover_body_edit = QTextEdit()
        self.cover_body_edit.setFixedHeight(80)
        form.addRow("Cover letter body", self.cover_body_edit)

        self.email_subject_edit = QLineEdit()
        form.addRow("Email subject", self.email_subject_edit)

        self.email_body_edit = QTextEdit()
        self.email_body_edit.setFixedHeight(80)
        form.addRow("Email body", self.email_body_edit)

        btn_row = QHBoxLayout()
        layout.addLayout(btn_row)

        self.generate_btn = QPushButton("Generate Next")
        self.skip_btn = QPushButton("Skip Company")
        self.approve_resume_btn = QPushButton("Approve Resume → PDF")
        self.approve_cover_btn = QPushButton("Approve Cover Letter → PDF")
        self.approve_email_btn = QPushButton("Approve Email → Draft/Send")

        self.approve_resume_btn.setEnabled(False)
        self.approve_cover_btn.setEnabled(False)
        self.approve_email_btn.setEnabled(False)
        self.skip_btn.setEnabled(False)

        self.generate_btn.clicked.connect(self.on_generate_clicked)
        self.skip_btn.clicked.connect(self.on_skip_clicked)
        self.approve_resume_btn.clicked.connect(self.on_approve_resume_clicked)
        self.approve_cover_btn.clicked.connect(self.on_approve_cover_clicked)
        self.approve_email_btn.clicked.connect(self.on_approve_email_clicked)

        btn_row.addWidget(self.generate_btn)
        btn_row.addWidget(self.skip_btn)
        btn_row.addWidget(self.approve_resume_btn)
        btn_row.addWidget(self.approve_cover_btn)
        btn_row.addWidget(self.approve_email_btn)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        layout.addWidget(QLabel("Log"))
        layout.addWidget(self.log, 1)

        self.csv_path = None
        self.resume_template_path = None
        self.cover_template_path = None
        self.output_dir = None
        self.companies_df = None

        self.base_dir = Path(__file__).resolve().parent
        self.skills_path = self.base_dir / "input_files" / "your_skills.txt"
        self.profile_path = self.base_dir / "input_files" / "your_profile.txt"
        self.name_path = self.base_dir / "input_files" / "your_name.txt"

    def log_line(self, msg: str):
        self.log.append(msg)

    def ensure_runner(self):
        if self.companies_df is None:
            raise RuntimeError("Load companies CSV first.")
        if self.resume_template_path is None:
            raise RuntimeError("Pick resume template first.")
        if self.cover_template_path is None:
            raise RuntimeError("Pick cover letter template first.")
        if self.output_dir is None:
            raise RuntimeError("Pick output folder first.")

        candidate_name = self.name_path.read_text(encoding="utf-8").strip()
        base_profile = self.profile_path.read_text(encoding="utf-8").strip()

        skills_raw = self.skills_path.read_text(encoding="utf-8")
        allowed_skills = [s.strip() for s in skills_raw.splitlines() if s.strip()]

        self.runner = ApplicationRunner(
            companies_df=self.companies_df,
            resume_template_path=self.resume_template_path,
            cover_template_path=self.cover_template_path,
            output_dir=self.output_dir,
            candidate_name=candidate_name,
            base_profile=base_profile,
            allowed_skills=allowed_skills,
            mail_mode=self.mode_combo.currentText(),
        )

    def push_ui_to_state(self):
        if not self.state or not self.state.assets:
            return

        assets = self.state.assets
        assets.resume_title = self.title_edit.text().strip()
        assets.profile_summary = self.profile_edit.toPlainText().strip()

        skills = [s.strip() for s in self.skills_edit.toPlainText().splitlines() if s.strip()]
        if len(skills) != 4:
            raise ValueError("Key skills must be exactly 4 lines.")
        assets.key_skills = skills

        assets.cover_letter.salutation = self.cover_salutation_edit.text().strip()
        assets.cover_letter.body = self.cover_body_edit.toPlainText().strip()

        assets.cold_email.subject = self.email_subject_edit.text().strip()
        assets.cold_email.body = self.email_body_edit.toPlainText().strip()

    def clear_fields(self):
        self.company_info.setText("Company: —")
        self.title_edit.clear()
        self.profile_edit.clear()
        self.skills_edit.clear()
        self.cover_salutation_edit.clear()
        self.cover_body_edit.clear()
        self.email_subject_edit.clear()
        self.email_body_edit.clear()

    def pick_csv(self):
        path, _ = QFileDialog.getOpenFileName(self, "Pick companies CSV", "", "CSV Files (*.csv)")
        if not path:
            return
        self.csv_path = path
        self.csv_label.setText(f"Companies CSV: {path}")
        self.companies_df = pd.read_csv(path)
        self.log_line(f"Loaded {len(self.companies_df)} companies from CSV.")

    def pick_resume_template(self):
        path, _ = QFileDialog.getOpenFileName(self, "Pick resume_template.docx", "", "Word Files (*.docx)")
        if not path:
            return
        self.resume_template_path = path
        self.resume_tpl_label.setText(f"Resume template: {path}")

    def pick_cover_template(self):
        path, _ = QFileDialog.getOpenFileName(self, "Pick cover_letter_template.docx", "", "Word Files (*.docx)")
        if not path:
            return
        self.cover_template_path = path
        self.cover_tpl_label.setText(f"Cover template: {path}")

    def pick_output(self):
        path = QFileDialog.getExistingDirectory(self, "Pick output folder")
        if not path:
            return
        self.output_dir = path
        self.out_label.setText(f"Output folder: {path}")

    def _run_in_thread(self, worker_obj: QObject, on_success):
        self.thread = QThread()
        self.worker = worker_obj
        self.worker.moveToThread(self.thread)

        self.thread.started.connect(self.worker.run)
        self.worker.error.connect(self.on_worker_error)
        self.worker.finished.connect(on_success)

        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)

        self.thread.start()

    def on_generate_clicked(self):
        try:
            if self.runner is None:
                self.ensure_runner()

            self.generate_btn.setEnabled(False)
            self.approve_resume_btn.setEnabled(False)
            self.approve_cover_btn.setEnabled(False)
            self.approve_email_btn.setEnabled(False)
            self.skip_btn.setEnabled(False)

            self.clear_fields()
            self.log_line("Checking duplicates + generating assets (OpenAI)...")
            self._run_in_thread(GenerateWorker(self.runner, force=False), self.on_generate_result)

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
            self.generate_btn.setEnabled(True)

    @Slot(object)
    def on_generate_result(self, state):
        self.state = state

        if getattr(state, "status", "") == "DUPLICATE":
            row = state.company_row
            dup = state.duplicate_record or {}
            msg = (
                "You already applied to this company (applications_log.csv).\n\n"
                f"Company: {row.get('name')}\n"
                f"Email: {row.get('email')}\n\n"
                f"Previous application date: {dup.get('applied_at', 'unknown')}\n\n"
                "Continue anyway?"
            )
            ans = QMessageBox.question(self, "Duplicate detected", msg, QMessageBox.Yes | QMessageBox.No)
            if ans == QMessageBox.Yes:
                self.log_line("Continuing despite duplicate...")
                self.generate_btn.setEnabled(False)
                self._run_in_thread(GenerateWorker(self.runner, force=True), self.on_generate_result)
                return
            else:
                self.log_line("Skipped duplicate.")
                self.runner.skip_current()
                self.generate_btn.setEnabled(True)
                self.skip_btn.setEnabled(False)
                return

        row = state.company_row
        assets = state.assets

        name = row.get("name", "")
        email = row.get("email", "")
        url = row.get("url", "")
        notes = row.get("notes", "")

        def esc(x: str) -> str:
            return str(x).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

        self.company_info.setText(
            f"<b>{esc(name)}</b> | {esc(email)}<br>"
            f"<a href='{esc(url)}'>{esc(url)}</a><br>"
            f"<i>{esc(notes)}</i>"
        )

        self.title_edit.setText(assets.resume_title)
        self.profile_edit.setPlainText(assets.profile_summary)
        self.skills_edit.setPlainText("\n".join(list(assets.key_skills)))

        self.cover_salutation_edit.setText(assets.cover_letter.salutation)
        self.cover_body_edit.setPlainText(assets.cover_letter.body)

        self.email_subject_edit.setText(assets.cold_email.subject)
        self.email_body_edit.setPlainText(assets.cold_email.body)

        self.log_line("Assets ready. Approve Resume + Cover Letter, then Email.")
        self.skip_btn.setEnabled(True)
        self.approve_resume_btn.setEnabled(True)
        self.approve_cover_btn.setEnabled(True)
        self.generate_btn.setEnabled(True)

    def on_skip_clicked(self):
        if self.runner is None:
            return
        self.runner.skip_current()
        self.state = None
        self.clear_fields()
        self.log_line("Skipped company. Click 'Generate Next' to continue.")
        self.approve_resume_btn.setEnabled(False)
        self.approve_cover_btn.setEnabled(False)
        self.approve_email_btn.setEnabled(False)
        self.generate_btn.setEnabled(True)

    def on_approve_resume_clicked(self):
        try:
            self.push_ui_to_state()
            self.generate_btn.setEnabled(False)
            self.approve_resume_btn.setEnabled(False)
            self.approve_cover_btn.setEnabled(False)
            self.approve_email_btn.setEnabled(False)

            self.log_line("Creating resume PDF (Word)...")
            self._run_in_thread(ResumeWorker(self.runner), self.on_resume_done)

        except Exception as e:
            QMessageBox.critical(self, "Validation error", str(e))
            self.approve_resume_btn.setEnabled(True)

    @Slot(str)
    def on_resume_done(self, pdf_path: str):
        self.log_line(f"Resume PDF created: {pdf_path}")
        self.generate_btn.setEnabled(True)
        self.approve_cover_btn.setEnabled(True)
        self.skip_btn.setEnabled(True)
        self._update_email_button()

    def on_approve_cover_clicked(self):
        try:
            self.push_ui_to_state()
            self.generate_btn.setEnabled(False)
            self.approve_resume_btn.setEnabled(False)
            self.approve_cover_btn.setEnabled(False)
            self.approve_email_btn.setEnabled(False)

            self.log_line("Creating cover letter PDF (Word)...")
            self._run_in_thread(CoverWorker(self.runner), self.on_cover_done)

        except Exception as e:
            QMessageBox.critical(self, "Validation error", str(e))
            self.approve_cover_btn.setEnabled(True)

    @Slot(str)
    def on_cover_done(self, pdf_path: str):
        self.log_line(f"Cover letter PDF created: {pdf_path}")
        self.generate_btn.setEnabled(True)
        self.skip_btn.setEnabled(True)
        self._update_email_button()

    def _update_email_button(self):
        if not self.state:
            self.approve_email_btn.setEnabled(False)
            return
        can_email = bool(self.state.resume_approved and self.state.cover_letter_approved)
        self.approve_email_btn.setEnabled(can_email)
        if can_email:
            self.log_line("Resume + cover letter ready. You can now approve email.")

    def on_approve_email_clicked(self):
        try:
            self.push_ui_to_state()
            self.generate_btn.setEnabled(False)
            self.approve_resume_btn.setEnabled(False)
            self.approve_cover_btn.setEnabled(False)
            self.approve_email_btn.setEnabled(False)
            self.skip_btn.setEnabled(False)

            self.runner.mail_mode = self.mode_combo.currentText()
            self.log_line(f"Creating Outlook email ({self.runner.mail_mode}) + logging...")

            self._run_in_thread(EmailWorker(self.runner), self.on_email_done)

        except Exception as e:
            QMessageBox.critical(self, "Validation error", str(e))
            self._update_email_button()
            self.generate_btn.setEnabled(True)
            self.skip_btn.setEnabled(True)

    @Slot()
    def on_email_done(self):
        self.log_line("Email drafted/sent and logged. Click 'Generate Next' to continue.")
        self.state = None
        self.clear_fields()
        self.generate_btn.setEnabled(True)
        self.skip_btn.setEnabled(False)
        self.approve_resume_btn.setEnabled(False)
        self.approve_cover_btn.setEnabled(False)
        self.approve_email_btn.setEnabled(False)

    @Slot(str)
    def on_worker_error(self, msg: str):
        self.log_line(f"ERROR: {msg}")
        QMessageBox.critical(self, "Worker error", msg)
        self.generate_btn.setEnabled(True)
        self.skip_btn.setEnabled(True)
        self.approve_resume_btn.setEnabled(False)
        self.approve_cover_btn.setEnabled(False)
        self.approve_email_btn.setEnabled(False)


def main():
    app = QApplication.instance()
    if app is None:
        app = QApplication(sys.argv)

    w = MainWindow()
    w.show()
    app.exec()


if __name__ == "__main__":
    main()
