# -*- coding: utf-8 -*-
"""Outlook email sender (draft or send) with attachments."""

import win32com.client as win32
from pathlib import Path
from typing import Iterable, Union, List


def send_email(
    adress: str,
    subject: str,
    body: str,
    attachments: Union[str, Path, Iterable[Union[str, Path]]],
    mode: str = "draft",
    display: bool = False,
):
    """
    Create an Outlook email with attachments.
    mode:
      - 'draft': saves to Drafts
      - 'send' : sends immediately
    display:
      - if True, opens the email inspector window (useful for manual final check)
    """
    # Normalize attachments to a list[Path]
    if attachments is None:
        paths: List[Path] = []
    elif isinstance(attachments, (str, Path)):
        paths = [Path(attachments)]
    else:
        paths = [Path(p) for p in attachments]

    outlook = win32.Dispatch("Outlook.Application")
    mail = outlook.CreateItem(0)

    mail.To = adress
    mail.Subject = subject
    mail.Body = body

    for p in paths:
        p = p.resolve()
        if not p.exists():
            raise FileNotFoundError(f"Attachment not found: {p}")
        mail.Attachments.Add(str(p))

    if display:
        mail.Display()

    mode = (mode or "draft").lower().strip()
    if mode == "send":
        mail.Send()
    else:
        mail.Save()  # Drafts
